package com.example.attendance_management_application;

public class ReminderActivity extends AppCompatActivity {
    private EditText reminderTitleEditText;
    private Button setReminderButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);

        reminderTitleEditText = findViewById(R.id.reminderTitleEditText);
        setReminderButton = findViewById(R.id.setReminderButton);

        setReminderButton.setOnClickListener(v -> setReminder());
    }

    private void setReminder() {
        String title = reminderTitleEditText.getText().toString();

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra("title", title);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.SECOND, 10); // 10 seconds later for demo

        alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);

        Toast.makeText(this, "Reminder Set", Toast.LENGTH_SHORT).show();
    }
}

