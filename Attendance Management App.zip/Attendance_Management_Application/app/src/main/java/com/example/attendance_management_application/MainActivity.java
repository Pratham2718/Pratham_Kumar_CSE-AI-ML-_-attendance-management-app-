package com.example.attendance_management_application;

import android.os.Bundle;

import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;



import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private RecyclerView eventRecyclerView;
    private FloatingActionButton scanQRButton;
    private FirebaseFirestore db;
    private EventAdapter adapter;
    private List<Event> eventList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eventRecyclerView = findViewById(R.id.eventRecyclerView);
        scanQRButton = findViewById(R.id.scanQRButton);
        db = FirebaseFirestore.getInstance();

        eventRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EventAdapter(eventList);
        eventRecyclerView.setAdapter(adapter);

        loadEvents();

        scanQRButton.setOnClickListener(v -> startQRScanner());
    }

    private void loadEvents() {
        db.collection("events").get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    eventList.clear();
                    for (DocumentSnapshot doc : queryDocumentSnapshots) {
                        Event event = doc.toObject(Event.class);
                        eventList.add(event);
                    }
                    adapter.notifyDataSetChanged();
                });
    }

    private void startQRScanner() {
        // TODO: Integrate QR scanning using ZXing library or MLKit
        Toast.makeText(this, "QR Scanner Launch Placeholder", Toast.LENGTH_SHORT).show();
    }
}
