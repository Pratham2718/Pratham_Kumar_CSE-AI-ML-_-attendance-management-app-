package com.example.attendance_management_application;

public class DashboardActivity extends AppCompatActivity {
    private RecyclerView registeredEventsRecyclerView;
    private List<Event> registeredEvents = new ArrayList<>();
    private FirebaseFirestore db;
    private EventAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        registeredEventsRecyclerView = findViewById(R.id.registeredEventsRecyclerView);
        db = FirebaseFirestore.getInstance();

        registeredEventsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EventAdapter(registeredEvents);
        registeredEventsRecyclerView.setAdapter(adapter);

        loadRegisteredEvents();
    }

    private void loadRegisteredEvents() {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        db.collection("attendance").whereEqualTo("userId", userId)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    registeredEvents.clear();
                    for (DocumentSnapshot doc : queryDocumentSnapshots) {
                        Event event = doc.toObject(Event.class);
                        registeredEvents.add(event);
                    }
                    adapter.notifyDataSetChanged();
                });
    }
}
