package com.example.attendance_management_application;

public class FacultyNotification {
    private String message;
    private String timestamp;

    public FacultyNotification() {
        // Empty constructor needed for Firebase
    }

    public FacultyNotification(String message, String timestamp) {
        this.message = message;
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public String getTimestamp() {
        return timestamp;
    }
}
