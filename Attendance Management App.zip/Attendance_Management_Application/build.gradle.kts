plugins {
    alias(libs.plugins.google.gms) apply false
}
// build.gradle.kts
// You can leave it almost empty or manage plugin versions globally if needed
fun plugins() {
    // (optional) Add plugins if needed globally
}


